---
name: TraderMind local sync
description: User requirement for syncing trade data while keeping the installed Windows app's database local.
---

The user wants trades entered in the web/mobile version to synchronize to the installed Windows version while keeping the Windows app's database on their computer, not in a cloud database. The Windows Electron app is the local sync hub; web/mobile clients keep their own local IndexedDB copy and synchronize when paired.

**Why:** The user wants voice-entered trades to reach their Windows installation without making a cloud database the primary store.

**How to apply:** Preserve Electron's `file://` loading and the existing database tables/schema. Keep Windows as the authoritative local hub. Do not migrate trade records to Replit PostgreSQL or another cloud store without explicit new approval.
