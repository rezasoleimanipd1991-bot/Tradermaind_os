---
name: TraderMind preview limits
description: Runtime constraint for previewing the imported TraderMind app in this environment.
---

For this TraderMind app, serve the supplied production bundle for preview when the Vite development dependency optimizer runs out of memory. Keep the original source intact; the production preview is only a runtime workaround.

**Why:** Direct development startup became unresponsive while esbuild optimized the large dependency graph, but the supplied bundle served successfully.

**How to apply:** Prefer the existing production preview command for the Replit preview in this constrained runtime. Revisit development mode only if its memory use or dependency optimization is changed.
